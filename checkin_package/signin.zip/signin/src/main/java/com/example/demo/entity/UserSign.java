package com.example.demo.entity;

public class UserSign {

    private int id;
    private String vrcode;
    private String username;

    public UserSign() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVrcode() {
        return vrcode;
    }

    public void setVrcode(String vrcode) {
        this.vrcode = vrcode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "UserSign{" +
                "id=" + id +
                ", vrcode='" + vrcode + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
