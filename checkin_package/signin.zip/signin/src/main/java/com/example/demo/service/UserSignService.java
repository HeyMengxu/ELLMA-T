package com.example.demo.service;

import com.example.demo.entity.UserSign;
import com.example.demo.repository.UserSignRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserSignService {

    @Autowired
    private UserSignRepository userSignRepository;

    public List<UserSign> getAllUserSigns() {
        return userSignRepository.findAll();
    }

    public int saveUserSign(UserSign userSign) {
        return userSignRepository.insert(userSign);
    }
    
    public UserSign queryByVrcode(String vrcode) {
        return userSignRepository.findByVrcode(vrcode);
    }

    public int updateNameByVrcode(UserSign userSign) {
        return userSignRepository.updateName(userSign);
    }
}