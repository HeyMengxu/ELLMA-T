package com.example.demo.repository;

import com.example.demo.entity.UserSign;
import com.example.demo.util.DataUtil;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserSignRepository {

    public List<UserSign> findAll() {
        String sql = "SELECT * FROM userSign order by id";
        return DataUtil.getJdbcTemplate().query(sql, new BeanPropertyRowMapper<>(UserSign.class));
    }

    public UserSign findById(Long id) {
        String sql = "SELECT * FROM userSign WHERE id = ?";
        return DataUtil.getJdbcTemplate().queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper<>(UserSign.class));
    }

    public UserSign findByVrcode(String varcode) {
        String sql = "SELECT * FROM userSign WHERE vrcode = ?";
        return DataUtil.getJdbcTemplate().queryForObject(sql, new Object[]{varcode}, new BeanPropertyRowMapper<>(UserSign.class));
    }

    public int insert(UserSign user) {
        String sql = "INSERT INTO userSign (vrcode, username) VALUES (?, ?)";
        return DataUtil.getJdbcTemplate().update(sql, user.getVrcode(), user.getUsername());
    }

    public int update(UserSign user) {
        String sql = "UPDATE userSign SET vrcode = ?, username = ? WHERE id = ?";
        return DataUtil.getJdbcTemplate().update(sql, user.getVrcode(), user.getUsername(), user.getId());
    }

    public int updateName(UserSign user) {
        String sql = "UPDATE userSign SET username = ? WHERE vrcode = ?";
        return DataUtil.getJdbcTemplate().update(sql, user.getUsername(), user.getVrcode());
    }

    public int delete(Long id) {
        String sql = "DELETE FROM userSign WHERE id = ?";
        return DataUtil.getJdbcTemplate().update(sql, id);
    }
}

