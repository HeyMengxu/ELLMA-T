package com.example.demo.controller;

import com.example.demo.dto.Result;
import com.example.demo.entity.UserSign;
import com.example.demo.service.UserSignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api-u")
public class UserSignController {

    @Autowired
    private UserSignService userSignService;


    @PostMapping(value = "/signIn")
    public Result createUser(@RequestBody UserSign userSign) {
        //打印输入
        System.out.println("userSign: " + userSign);
        if(userSign.getUsername() == null || userSign.getUsername().trim().length() == 0) {
            return Result.error("name is required.");
        }
        //查询
        try {
            UserSign user = userSignService.queryByVrcode(userSign.getVrcode());
            if (user == null) {
                return Result.error("System is not available, ask for help.");
            }
            System.out.println("user: " + user.toString());
            if (user.getUsername().equals("available")) {
                userSignService.updateNameByVrcode(userSign);
                return Result.ok();
            } else {
                return Result.error("System is busy, ask for help.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("System is not available, ask for help.");
        }
    }
}